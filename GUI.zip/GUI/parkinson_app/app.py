import numpy as np
from flask import Flask, render_template
from preprocess import get_ica_result, get_butterworth_result,get_raw_result,get_scaling_result,get_segmentation_result,get_feature_extraction_result
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.layers import Input, Dense
from spektral.layers import GCNConv
from sklearn.model_selection import KFold
from io import BytesIO
import matplotlib.pyplot as plt
import io
import base64
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_score, recall_score, f1_score


# Cache for raw EEG data
raw_eeg_cache = {
    "unhealthy": None,
    "healthy": None
}


# Cache for different stages
ica_cache = {
    "unhealthy": None,
    "healthy": None
}

butter_cache = {
    "unhealthy": None,
    "healthy": None
}

scaling_cache = {
    "unhealthy": None,
    "healthy": None
}

segmentation_cache = {
    "unhealthy": [],
    "healthy": []
}

feature_extraction_cache = {
    "unhealthy": None,
    "healthy": None,
    "nf1": None,
    "nf2": None,
    "nf3": None,
    "adj1": None,
    "adj2": None,
    "adj3": None,
    "labels": None
}


split_cache = {  # New cache for split data
    "clients_data": None,
    "test_data": None,
    "y_test": None
}


global_model = None
local_models = []


app = Flask(__name__)

def create_gcnn_model(input_shape, adjacency_shape):
    inputs = Input(shape=input_shape)
    adj = Input(shape=adjacency_shape)
    x = GCNConv(128, activation='relu')([inputs, adj])
    x = GCNConv(64, activation='relu')([x, adj])
    x = tf.reduce_mean(x, axis=1)
    x = Dense(128, activation='relu')(x)
    x = Dense(64, activation='relu')(x)
    x = Dense(32, activation='relu')(x)
    outputs = Dense(1, activation='sigmoid')(x)
    model = tf.keras.Model(inputs=[inputs, adj], outputs=outputs)
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model


@app.route('/')
def index():
    return render_template('index.html')

@app.route("/process")
def processes():
    return render_template("process.html")

@app.route('/ica')
def ica_page():
    result, ica_unhealthy, ica_healthy = get_ica_result()
    ica_cache["unhealthy"] = ica_unhealthy
    ica_cache["healthy"] = ica_healthy

    unhealthy_values = ica_unhealthy[:1].tolist()
    healthy_values = ica_healthy[:1].tolist()

    return render_template("ica.html",
                           result=result,
                           unhealthy_values=unhealthy_values,
                           healthy_values=healthy_values)

@app.route('/butterworth')
def butterworth_page():
    if ica_cache["unhealthy"] is None or ica_cache["healthy"] is None:
        return "<h3>Please run ICA first.</h3><a href='/process'>Go Back</a>"

    result, filtered_unhealthy, filtered_healthy = get_butterworth_result(
        ica_cache["unhealthy"],
        ica_cache["healthy"]
    )

    butter_cache["unhealthy"] = filtered_unhealthy
    butter_cache["healthy"] = filtered_healthy

    unhealthy_values = filtered_unhealthy[:1].tolist()
    healthy_values = filtered_healthy[:1].tolist()

    return render_template("butterworth.html",
                           result=result,
                           unhealthy_values=unhealthy_values,
                           healthy_values=healthy_values)

@app.route('/scaling')
def scaling_page():
    if butter_cache["unhealthy"] is None or butter_cache["healthy"] is None:
        return "<h3>Please run Butterworth filter first.</h3><a href='/process'>Go Back</a>"

    result, scaled_unhealthy, scaled_healthy = get_scaling_result(
        np.array(butter_cache["unhealthy"]),
        np.array(butter_cache["healthy"])
    )

    scaling_cache["unhealthy"] = scaled_unhealthy
    scaling_cache["healthy"] = scaled_healthy

    unhealthy_values = scaled_unhealthy[:1].tolist()
    healthy_values = scaled_healthy[:1].tolist()

    return render_template("scaling.html",
                           result=result,
                           unhealthy_values=unhealthy_values,
                           healthy_values=healthy_values)

@app.route('/segmentation')
def segmentation_page():
    if scaling_cache["unhealthy"] is None or scaling_cache["healthy"] is None:
        return "<h3>Please run Scaling first.</h3><a href='/process'>Go Back</a>"

    # Get the segmentation results
    result, uh1, uh2, uh3, h1, h2, h3 = get_segmentation_result(
        np.array(scaling_cache["unhealthy"]),
        np.array(scaling_cache["healthy"])
    )

    # Check if segmentation returned valid data
    if uh1 is None or len(uh1) == 0:  # Check if the array is empty or None
        return "<h3>Error during segmentation. Not enough data.</h3><a href='/process'>Go Back</a>"

    # Store the segmented data in the cache
    segmentation_cache["unhealthy"] = [uh1, uh2, uh3]
    segmentation_cache["healthy"] = [h1, h2, h3]

    # Print the cache contents for debugging
    print(f"Segmentation Cache (unhealthy): {segmentation_cache['unhealthy']}")
    print(f"Segmentation Cache (healthy): {segmentation_cache['healthy']}")
    
    print("Unhealthy shapes:", uh1.shape, uh2.shape, uh3.shape)
    print("Healthy shapes:", h1.shape, h2.shape, h3.shape)
    # Return the result to the user
    return render_template("segmentation.html",
                       result=result,
                       unhealthy_shape1=str(uh1.shape),
                       unhealthy_shape2=str(uh2.shape),
                       unhealthy_shape3=str(uh3.shape),
                       healthy_shape1=str(h1.shape),
                       healthy_shape2=str(h2.shape),
                       healthy_shape3=str(h3.shape))

   


@app.route('/features')
def feature_extraction_page():
    if segmentation_cache["unhealthy"] == [] or segmentation_cache["healthy"] == []:
        return "<h3>Please run Segmentation first.</h3><a href='/process'>Go Back</a>"
    
    print("Unhealthy Segmentation Shape:", np.concatenate(segmentation_cache["unhealthy"]).shape)
    print("Healthy Segmentation Shape:", np.concatenate(segmentation_cache["healthy"]).shape)

    # Perform feature extraction
    result, nf1, nf2, nf3, adj1, adj2, adj3, labels = get_feature_extraction_result(
        np.concatenate(segmentation_cache["unhealthy"]),
        np.concatenate(segmentation_cache["healthy"])
    )

    # Check if the returned feature extraction data is None or empty
    if any(arr is None or arr.size == 0 for arr in [nf1, nf2, nf3, adj1, adj2, adj3, labels]):
        return "<h3>Error: Feature extraction returned empty or invalid data!</h3><a href='/process'>Go Back</a>"

    # Save the results in the cache
    feature_extraction_cache["unhealthy"] = np.concatenate(segmentation_cache["unhealthy"])
    feature_extraction_cache["healthy"] = np.concatenate(segmentation_cache["healthy"])
    feature_extraction_cache["nf1"] = nf1
    feature_extraction_cache["nf2"] = nf2
    feature_extraction_cache["nf3"] = nf3
    feature_extraction_cache["adj1"] = adj1
    feature_extraction_cache["adj2"] = adj2
    feature_extraction_cache["adj3"] = adj3
    feature_extraction_cache["labels"] = labels

    # Print out the shapes of the feature extraction results to debug
    print("Feature Extraction Shapes:")
    print(f"nf1: {nf1.shape}")
    print(f"nf2: {nf2.shape}")
    print(f"nf3: {nf3.shape}")
    print(f"adj1: {adj1.shape}")
    print(f"adj2: {adj2.shape}")
    print(f"adj3: {adj3.shape}")
    print(f"labels: {labels.shape}")

    # Return the result and show the shapes in the template
    return render_template("feature_extraction.html",
                           result=result,
                           nf1_shape=nf1.shape,
                           nf2_shape=nf2.shape,
                           nf3_shape=nf3.shape,
                           adj1_shape=adj1.shape,
                           adj2_shape=adj2.shape,
                           adj3_shape=adj3.shape,
                           label_shape=labels.shape)

# After performing feature extraction, print the feature_extraction_cache to confirm
print("Feature Extraction Cache:")
print(feature_extraction_cache)



@app.route('/split-data')
def splitting_page():
    # Load from cache
    X1 = feature_extraction_cache["nf1"]
    X2 = feature_extraction_cache["nf2"]
    X3 = feature_extraction_cache["nf3"]
    A1 = feature_extraction_cache["adj1"]
    A2 = feature_extraction_cache["adj2"]
    A3 = feature_extraction_cache["adj3"]
    y = feature_extraction_cache["labels"]

    if any(item is None for item in [X1, X2, X3, A1, A2, A3, y]):
        return "<h3>Error: Complete feature extraction first.</h3><a href='/process'>Go Back</a>"

    # Perform train-test split
    X_train_1, X_test_1, A_train_1, A_test_1, \
    X_train_2, X_test_2, A_train_2, A_test_2, \
    X_train_3, X_test_3, A_train_3, A_test_3, \
    y_train, y_test = train_test_split(
        X1, A1, X2, A2, X3, A3, y, test_size=0.2, random_state=42
    )

    # Store in cache
    split_cache["clients_data"] = [
        (X_train_1, A_train_1, y_train),
        (X_train_2, A_train_2, y_train),
        (X_train_3, A_train_3, y_train)
    ]
    split_cache["test_data"] = [
        [X_test_1, A_test_1],
        [X_test_2, A_test_2],
        [X_test_3, A_test_3]
    ]
    split_cache["y_test"] = y_test

    return render_template('split.html',
        train_samples=len(y_train),
        test_samples=len(y_test),
        client1_train=X_train_1.shape[0],
        client2_train=X_train_2.shape[0],
        client3_train=X_train_3.shape[0],
        client1_test=X_test_1.shape[0],
        client2_test=X_test_2.shape[0],
        client3_test=X_test_3.shape[0]
    )

def federated_training():
    global global_model
    global local_models

    global_model = create_gcnn_model((32, 12), (32, 32))

    local_model1 = create_gcnn_model((32, 12), (32, 32))
    local_model2 = create_gcnn_model((32, 12), (32, 32))
    local_model3 = create_gcnn_model((32, 12), (32, 32))
    local_models = [local_model1, local_model2, local_model3]  # <-- fixed global assignment

    initial_weights = global_model.get_weights()

    clients_data = split_cache["clients_data"]
    test_data = split_cache["test_data"]
    y_test = split_cache["y_test"]

    n_rounds = 10
    k_folds = 5

    for round in range(n_rounds):
        print(f"\n========== FL Round {round + 1} ==========")
        client_weights = []

        for i, (X_train, A_train, y_train) in enumerate(clients_data):
            print(f"\nTraining on Client {i+1} with {k_folds}-Fold Cross-Validation...")
            kf = KFold(n_splits=k_folds, shuffle=True, random_state=42)
            fold_weights = []

            for fold, (train_idx, val_idx) in enumerate(kf.split(X_train)):
                print(f"  Fold {fold + 1}/{k_folds}")

                X_train_fold, A_train_fold, y_train_fold = X_train[train_idx], A_train[train_idx], y_train[train_idx]
                X_val_fold, A_val_fold, y_val_fold = X_train[val_idx], A_train[val_idx], y_train[val_idx]

                local_models[i].set_weights(global_model.get_weights())

                local_models[i].fit(
                    [X_train_fold, A_train_fold], y_train_fold,
                    epochs=10, batch_size=32,
                    validation_data=([X_val_fold, A_val_fold], y_val_fold),
                    verbose=0
                )

                fold_weights.append(local_models[i].get_weights())

            # Average fold weights for current client
            avg_weights = [np.mean([fold[i] for fold in fold_weights], axis=0) for i in range(len(fold_weights[0]))]
            client_weights.append(avg_weights)

        # Aggregate client weights
        new_weights = [np.mean([client[i] for client in client_weights], axis=0) for i in range(len(client_weights[0]))]
        global_model.set_weights(new_weights)

        weight_changes = sum(
            np.linalg.norm(global_layer - initial_layer)
            for global_layer, initial_layer in zip(global_model.get_weights(), initial_weights)
        )
        print(f"Weight Change after Round {round + 1}: {weight_changes:.4f}")

        for j in range(len(test_data)):
            loss, accuracy = global_model.evaluate(test_data[j], y_test, verbose=0)
            print(f"Global Model Accuracy after Round {round + 1} on Client {j+1}: {accuracy:.4f}")

        # Update local models with latest global weights
        initial_weights = global_model.get_weights()
        for k in range(len(local_models)):
            local_models[k].set_weights(initial_weights)

    return "Model training completed successfully!"


@app.route('/train-model')
def train_model():
    if split_cache["clients_data"] is None:
        return "<h3>Error: Please split the data first!</h3><a href='/process'>Go Back</a>"

    message = federated_training()
    return render_template("model.html", message=message)



def evaluate_model(model, test_data, y_test, model_name):
    y_pred = model.predict(test_data)
    y_pred = (y_pred > 0.5).astype(int) 

    report = classification_report(y_test, y_pred, digits=4)
    cnf_matrix = confusion_matrix(y_test, y_pred)

    TN = cnf_matrix[0][0]
    FN = cnf_matrix[1][0]
    TP = cnf_matrix[1][1]
    FP = cnf_matrix[0][1]

    FP = float(FP)
    FN = float(FN)
    TP = float(TP)
    TN = float(TN)

    specificity = TN / (TN + FP)
    sensitivity = TP / (TP + FN)
    fpr = FP / (FP + TN)
    
    
    print(f"\n=== {model_name} ===")
    print(f"Classification report :{report}")
    print(f"Confusion Matrix:\n{cnf_matrix}")
    print(f"Accuracy     : {accuracy_score(y_test, y_pred):.4f}")
    print(f"Precision    : {precision_score(y_test, y_pred):.4f}")
    print(f"Recall       : {recall_score(y_test, y_pred):.4f}")
    print(f"F1 Score     : {f1_score(y_test, y_pred):.4f}")
    print(f"Specificity  : {specificity:.4f}")
    print(f"Sensitivity  : {sensitivity:.4f}")
    print(f"FPR          : {fpr:.4f}")

    return {
        "model_name": model_name,
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1_score": f1_score(y_test, y_pred),
        "specificity": specificity,
        "sensitivity": sensitivity,
        "false_positive_rate": fpr,
        "confusion_matrix": cnf_matrix.tolist()
    }


@app.route('/run-metrics')
def run_metrics():
    if split_cache["test_data"] is None or global_model is None or not local_models:
        return "<h3>Please make sure training is completed.</h3><a href='/process'>Go Back</a>"

    test_data = split_cache["test_data"]
    y_test = split_cache["y_test"]

    eval_results = []

    for j, model in enumerate(local_models):
        res = evaluate_model(model, test_data[j], y_test, f"Local Model {j+1}")
        eval_results.append(res)

    for k in range(len(test_data)):
        res = evaluate_model(global_model, test_data[k], y_test, f"Global Model {k+1}")
        eval_results.append(res)

    return render_template("model_results.html", results=eval_results)




@app.route('/show-metrics-plot')
def show_metrics_plot():
    if split_cache["test_data"] is None or global_model is None or not local_models:
        return "<h3>Please make sure training is completed.</h3><a href='/process'>Go Back</a>"

    test_data = split_cache["test_data"]
    y_test = split_cache["y_test"]

    local_plots_base64 = []
    global_plots_base64 = []

    # Local models evaluation
    for j, model in enumerate(local_models):
        res = evaluate_model(model, test_data[j], y_test, f"Local Model {j+1}")
        image_base64 = generate_metric_plot(res)
        local_plots_base64.append(image_base64)

    # Global models evaluation
    for k in range(len(test_data)):
        res = evaluate_model(global_model, test_data[k], y_test, f"Global Model {k+1}")
        image_base64 = generate_metric_plot(res)
        global_plots_base64.append(image_base64)

    return render_template("metrics_plot.html", local_images=local_plots_base64, global_images=global_plots_base64)

def generate_metric_plot(result):
    metrics = {
        "Accuracy": result["accuracy"],
        "Precision": result["precision"],
        "Recall": result["recall"],
        "F1-Score": result["f1_score"],
        "Specificity": result["specificity"],
    }

    fig, ax = plt.subplots(figsize=(8, 5.5))

    # Different colors for each metric
    colors = ['#69b3a2', '#ff9999', '#9ecae1', '#f4b400', '#ab63fa', '#ff7f0e']
    bars = ax.bar(metrics.keys(), metrics.values(), color=colors[:len(metrics)])

    # Annotate values inside bars
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f"{height:.4f}",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 5),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=11, color='black', fontweight='bold')

    ax.set_title(result["model_name"], fontsize=15, fontweight='bold', pad=15)
    ax.set_ylim(0, 1.10)

    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=11)

    for spine in ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1.4)

    fig.tight_layout(pad=2.5)

    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    plt.close(fig)

    return image_base64






# Function to generate EEG plot (based on your raw data format)
def generate_eeg_plot(data, title):
    plt.figure(figsize=(12, 6))  # Increase size for better visualization
    plt.plot(data, color='b')  # Plot using matplotlib (raw data directly)
    plt.title(title)
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    
    # Save the plot as a base64 encoded string to display in the browser
    img = BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')  # bbox_inches='tight' to avoid clipping
    img.seek(0)
    img_base64 = base64.b64encode(img.getvalue()).decode('utf8')
    plt.close()
    return img_base64

# Function to generate ICA plot
def generate_ica_plot(data):
    plt.figure(figsize=(10, 6))
    plt.plot(data)
    plt.title('ICA Plot')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    
    # Save the plot as a base64 encoded string to display in the browser
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    img_base64 = base64.b64encode(img.getvalue()).decode('utf8')
    plt.close()
    return img_base64

# Function to generate Butterworth plot
def generate_butterworth_plot(data):
    plt.figure(figsize=(10, 6))
    plt.plot(data)
    plt.title('Butterworth Filtered Plot')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    
    # Save the plot as a base64 encoded string to display in the browser
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    img_base64 = base64.b64encode(img.getvalue()).decode('utf8')
    plt.close()
    return img_base64

@app.route('/show-eeg-plot')
def show_eeg_plot():
    # Retrieve raw EEG data from the cache (replace with actual data)
    unhealthy, healthy = get_raw_result()
    
    raw_eeg_cache['unhealthy'] = unhealthy
    raw_eeg_cache['healthy'] = healthy
    
    # Check if raw EEG data is available
    if raw_eeg_cache["unhealthy"] is None or raw_eeg_cache["healthy"] is None:
        return "<h3>Please run the processing first.</h3><a href='/process'>Go Back</a>"
    
    # Get the EEG data (use either unhealthy or healthy data for plot)
    eeg_data = raw_eeg_cache["unhealthy"]  # Just an example, adjust accordingly
    
    # Generate the EEG plot
    eeg_plot = generate_eeg_plot(eeg_data, title="EEG Signal")
    
    # Render the plot in the template
    return render_template('plot.html', plot=eeg_plot, plot_title=" Unhealthy EEG Plot")

@app.route('/show-ica-plot')
def show_ica_plot():
    if ica_cache["unhealthy"] is None or ica_cache["healthy"] is None:
        return "<h3>Please run ICA first.</h3><a href='/process'>Go Back</a>"
    
    # Get ICA data
    ica_data = ica_cache["unhealthy"]
    ica_plot = generate_ica_plot(ica_data)
    
    # Return the ICA plot with the "Show Butterworth Plot" button
    return render_template('plot.html', plot=ica_plot, plot_title="Unhealthy ICA Plot", show_ica=True)

@app.route('/show-butterworth-plot')
def show_butterworth_plot():
    if butter_cache["unhealthy"] is None or butter_cache["healthy"] is None:
        return "<h3>Please run Butterworth filter first.</h3><a href='/process'>Go Back</a>"
    
    # Get Butterworth filtered data
    butter_data = butter_cache["unhealthy"]
    butter_plot = generate_butterworth_plot(butter_data)
    
    # Return the Butterworth plot
    return render_template('plot.html', plot=butter_plot, plot_title="Unhealthy  Butterworth Filter Plot", show_ica=False)



if __name__ == '__main__':
    app.run(debug=True,use_reloader=False)







































