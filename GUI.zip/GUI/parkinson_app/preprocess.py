import mne
import numpy as np
from sklearn.decomposition import FastICA
from scipy.signal import butter, lfilter
from sklearn.preprocessing import StandardScaler
from scipy.stats import skew, kurtosis
from scipy.signal import welch, hilbert
import matplotlib.pyplot as plt



# File paths
unhealthy_files = [
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/parkinson/unhealthy/sub-pd12_ses-off_task-rest_eeg.bdf',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/parkinson/unhealthy/sub-pd13_ses-off_task-rest_eeg.bdf',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/parkinson/unhealthy/sub-pd9_ses-off_task-rest_eeg.bdf'
]

healthy_files = [
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/parkinson/healthy/sub-hc1_ses-hc_task-rest_eeg.bdf',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/parkinson/healthy/sub-hc31_ses-hc_task-rest_eeg.bdf',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/parkinson/healthy/sub-hc25_ses-hc_task-rest_eeg.bdf'
]



def plot_eeg(raw_data, title):
    raw_data.plot(title=title, show=True, block=True)


def ica_plots(unhealthy_combined, healthy_combined, ica_unhealthy, ica_healthy):
    plt.figure(figsize=(8, 8))

    plt.subplot(4, 1, 1)
    plt.title('Unhealthy Signals')
    plt.plot(unhealthy_combined)
    
    plt.subplot(4, 1, 2)
    plt.title('Healthy Signals')
    plt.plot(healthy_combined)

    plt.subplot(4, 1, 3)
    plt.title('ICA Unhealthy Signals')
    plt.plot(ica_unhealthy)

    plt.subplot(4, 1, 4)
    plt.title('ICA Healthy (ICA)')
    plt.plot(ica_healthy)

    plt.tight_layout()
    plt.show()


def load_data(files):
    raws = []
    for f in files:
        raw = mne.io.read_raw_bdf(f, preload=True)
        eeg_channels = [ch for ch in raw.ch_names if not ch.startswith("EXG") and ch != "Status"]
        raw = raw.pick_channels(eeg_channels)
        raws.append(raw)
    combined = mne.concatenate_raws(raws)
    plot_eeg(combined, title='EEG Data')  # Plot here
    return combined.get_data().T



def ica_process(data, n_components=32):
    ica = FastICA(n_components=n_components, random_state=42)
    return ica.fit_transform(data)

def butterworth_filter(data, lowcut=0.5, highcut=40, fs=512, order=5):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    filtered_data = np.zeros_like(data)
    for i in range(data.shape[1]):
        filtered_data[:, i] = lfilter(b, a, data[:, i])
    return filtered_data

# ---------- GET RAW ----------
def get_raw_result():
    unhealthy = load_data(unhealthy_files)
    healthy = load_data(healthy_files)
    return unhealthy, healthy

# ---------- GET ICA ----------
def get_ica_result():
    unhealthy = load_data(unhealthy_files)
    healthy = load_data(healthy_files)
    ica_unhealthy = ica_process(unhealthy)
    ica_healthy = ica_process(healthy)
    ica_plots(unhealthy, healthy, ica_unhealthy, ica_healthy)
    result = f"ICA Processed: Unhealthy shape = {ica_unhealthy.shape}, Healthy shape = {ica_healthy.shape}"
    return result, ica_unhealthy, ica_healthy

# --------- GET BUTTERWORTH ----------
def get_butterworth_result(ica_unhealthy, ica_healthy):
    filtered_unhealthy = butterworth_filter(ica_unhealthy)
    filtered_healthy = butterworth_filter(ica_healthy)
    result = f"Butterworth Processed: Unhealthy shape = {filtered_unhealthy.shape}, Healthy shape = {filtered_healthy.shape}"
    return result, filtered_unhealthy, filtered_healthy


def get_scaling_result(filtered_unhealthy, filtered_healthy):
    scaler = StandardScaler()

    # Apply scaling to each feature independently (column-wise)
    scaled_unhealthy = np.array([
        scaler.fit_transform(filtered_unhealthy[:, i].reshape(-1, 1)).flatten()
        for i in range(filtered_unhealthy.shape[1])
    ]).T

    scaled_healthy = np.array([
        scaler.fit_transform(filtered_healthy[:, i].reshape(-1, 1)).flatten()
        for i in range(filtered_healthy.shape[1])
    ]).T

    result = "Scaling completed using StandardScaler (feature-wise)."
    return result, scaled_unhealthy, scaled_healthy



# Segmentation Function (same as in Parkinson's main code)
def segment_eeg(data, window_size=512, stride=64):
    segments = [data[i:i + window_size] for i in range(0, len(data) - window_size + 1, stride)]
    return np.array(segments)

def get_segmentation_result(scaled_unhealthy, scaled_healthy, window_size=512, stride=64):
    # Apply segmentation on both unhealthy and healthy data
    segmented_unhealthy = segment_eeg(scaled_unhealthy, window_size, stride)
    segmented_healthy = segment_eeg(scaled_healthy, window_size, stride)

    # Segment the data into different chunks (similar to your approach)
    segmented_unhealthy1 = segmented_unhealthy[:500]
    segmented_unhealthy2 = segmented_unhealthy[1500:2000]
    segmented_unhealthy3 = segmented_unhealthy[2000:2500]

    segmented_healthy1 = segmented_healthy[:500]
    segmented_healthy2 = segmented_healthy[1500:2000]
    segmented_healthy3 = segmented_healthy[2000:2500]

    # Return results
    return ("Segmentation Results Are:",
            segmented_unhealthy1, segmented_unhealthy2, segmented_unhealthy3,
            segmented_healthy1, segmented_healthy2, segmented_healthy3)


# Time-Domain Features (7 per channel)
# Hjorth Parameters
def hjorth_parameters(signal):
    first_derivative, second_derivative = np.diff(signal), np.diff(np.diff(signal))
    activity = np.var(signal)
    mobility = np.sqrt(np.var(first_derivative) / activity)
    complexity = np.sqrt(np.var(second_derivative) / np.var(first_derivative))
    return activity, mobility, complexity

# Time-Domain Features (6 per channel)
def extract_time_features(segment):
    return np.array([
        [np.mean(ch), np.var(ch), skew(ch), kurtosis(ch), *hjorth_parameters(ch)]
        for ch in segment.T
    ])

# Frequency-Domain Features (5 per channel)
def extract_frequency_features(segment, fs=512):
    bands = {"delta": (0.5, 4), "theta": (4, 8), "alpha": (8, 13), "beta": (13, 30), "gamma": (30, 40)}
    features = []
    for ch in segment.T:
        freqs, psd = welch(ch, fs=fs, nperseg=256)
        band_powers = [np.sum(psd[(freqs >= low) & (freqs < high)]) for low, high in bands.values()]
        features.append(band_powers)
    return np.array(features)

# Graph Connectivity using Hilbert Transform
def compute_connectivity_matrix(segment):
    hilbert_transform = hilbert(segment, axis=0)
    phase_angles = np.angle(hilbert_transform)
    connectivity_matrix = np.abs(np.exp(1j * (phase_angles[:, None, :] - phase_angles[:, :, None])).mean(axis=0))
    np.fill_diagonal(connectivity_matrix, 1)
    return connectivity_matrix

# Extract node features and adjacency matrices from EEG segments
def segmented_features(segments, label):
    node_features = []
    adjacency_matrices = []
    labels = []

    for segment in segments:
        time_feats = extract_time_features(segment)
        freq_feats = extract_frequency_features(segment)
        conn_matrix = compute_connectivity_matrix(segment)

        node_feat_matrix = np.hstack([time_feats, freq_feats])
        node_features.append(node_feat_matrix)
        adjacency_matrices.append(conn_matrix)
        labels.append(label)

    return np.array(node_features), np.array(adjacency_matrices), np.array(labels)

# Wrap everything into a callable function
def get_feature_extraction_result(segments_unhealthy, segments_healthy):
    uh1, uh2, uh3 = segments_unhealthy[:500], segments_unhealthy[500:1000], segments_unhealthy[1000:1500]
    h1, h2, h3 = segments_healthy[:500], segments_healthy[500:1000], segments_healthy[1000:1500]

    nf1, adj1, lab1 = segmented_features(uh1, 0)
    nf2, adj2, lab2 = segmented_features(uh2, 0)
    nf3, adj3, lab3 = segmented_features(uh3, 0)
    nf4, adj4, lab4 = segmented_features(h1, 1)
    nf5, adj5, lab5 = segmented_features(h2, 1)
    nf6, adj6, lab6 = segmented_features(h3, 1)

    final_nf1 = np.concatenate((nf1, nf4), axis=0)
    final_nf2 = np.concatenate((nf2, nf5), axis=0)
    final_nf3 = np.concatenate((nf3, nf6), axis=0)

    final_adj1 = np.concatenate((adj1, adj4), axis=0)
    final_adj2 = np.concatenate((adj2, adj5), axis=0)
    final_adj3 = np.concatenate((adj3, adj6), axis=0)

    final_labels1 = np.concatenate((lab1, lab4), axis=0)

    return (
        "Feature_Extraction Executed Successfully",
        final_nf1, final_nf2, final_nf3,
        final_adj1, final_adj2, final_adj3, final_labels1)


















