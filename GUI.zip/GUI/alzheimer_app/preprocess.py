import mne
import numpy as np
from sklearn.decomposition import FastICA
from scipy.signal import butter, lfilter
from sklearn.preprocessing import StandardScaler
from scipy.stats import skew, kurtosis
from scipy.signal import welch, hilbert
import matplotlib.pyplot as plt


# File paths
unhealthy_files = [
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/alzheimer/unhealthy/sub-001_task-eyesclosed_eeg.set',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/alzheimer/unhealthy/sub-003_task-eyesclosed_eeg.set',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/alzheimer/unhealthy/sub-017_task-eyesclosed_eeg.set',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/alzheimer/unhealthy/sub-006_task-eyesclosed_eeg.set'
]

healthy_files = [
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/alzheimer/healthy/sub-037_task-eyesclosed_eeg.set',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/alzheimer/healthy/sub-039_task-eyesclosed_eeg.set',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/alzheimer/healthy/sub-049_task-eyesclosed_eeg.set'
]


def ica_plots(unhealthy_combined, healthy_combined, ica_unhealthy, ica_healthy):
    plt.figure(figsize=(10, 10))

    plt.subplot(4, 1, 1)
    plt.title('Unhealthy Signals (Before ICA)')
    plt.plot(unhealthy_combined)

    plt.subplot(4, 1, 2)
    plt.title('Healthy Signals (Before ICA)')
    plt.plot(healthy_combined)

    plt.subplot(4, 1, 3)
    plt.title('Unhealthy Signals (After ICA)')
    plt.plot(ica_unhealthy)

    plt.subplot(4, 1, 4)
    plt.title('Healthy Signals (After ICA)')
    plt.plot(ica_healthy)

    plt.tight_layout()
    plt.show()


def load_data(files):
    raws = [mne.io.read_raw_eeglab(f, preload=True) for f in files]
    concatenated = mne.concatenate_raws(raws)
    plot_eeg(concatenated, title="EEG Data")  # Plot added here
    return concatenated.get_data().T

def ica_process(data, n_components=19):
    ica = FastICA(n_components=n_components, random_state=42)
    return ica.fit_transform(data)


def plot_eeg(raw_data, title):
    raw_data.plot(title=title, show=True, block=True)

def butterworth_filter(data, lowcut=0.5, highcut=40, fs=500, order=5):
    nyquist = 0.5 * fs
    low, high = lowcut / nyquist, highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    return np.array([lfilter(b, a, ch) for ch in data.T]).T


def get_raw_result():
    unhealthy = load_data(unhealthy_files)
    healthy = load_data(healthy_files)
    return unhealthy, healthy

def get_ica_result():
    unhealthy = load_data(unhealthy_files)
    healthy = load_data(healthy_files)
    ica_unhealthy = ica_process(unhealthy)
    ica_healthy = ica_process(healthy)
    ica_plots(unhealthy, healthy, ica_unhealthy, ica_healthy)
    result = f"ICA Processed: Unhealthy shape = {ica_unhealthy.shape}, Healthy shape = {ica_healthy.shape}"
    return result,ica_unhealthy,ica_healthy

def get_butterworth_result(ica_unhealthy, ica_healthy):
    filtered_unhealthy = butterworth_filter(ica_unhealthy)
    filtered_healthy = butterworth_filter(ica_healthy)
    result = f"Butterworth Processed: Unhealthy shape = {filtered_unhealthy.shape}, Healthy shape = {filtered_healthy.shape}"
    return result, filtered_unhealthy, filtered_healthy



def get_scaling_result(filtered_unhealthy, filtered_healthy):
    scaler = StandardScaler()

    # Apply scaling to each feature independently (column-wise)
    scaled_unhealthy = np.array([
        scaler.fit_transform(filtered_unhealthy[:, i].reshape(-1, 1)).flatten()
        for i in range(filtered_unhealthy.shape[1])
    ]).T

    scaled_healthy = np.array([
        scaler.fit_transform(filtered_healthy[:, i].reshape(-1, 1)).flatten()
        for i in range(filtered_healthy.shape[1])
    ]).T

    result = "Scaling completed using StandardScaler (feature-wise)."
    return result, scaled_unhealthy, scaled_healthy




def segment_eeg(data, window_size=500, stride=125):
    segments = [data[i:i + window_size] for i in range(0, len(data) - window_size + 1, stride)]
    return np.array(segments)

def get_segmentation_result(scaled_unhealthy, scaled_healthy):
    segmented_unhealthy = segment_eeg(scaled_unhealthy)
    segmented_healthy = segment_eeg(scaled_healthy)

    segmented_unhealthy1 = segmented_unhealthy[:400]
    segmented_unhealthy2 = segmented_unhealthy[400:800]
    segmented_unhealthy3 = segmented_unhealthy[800:1200]

    segmented_healthy1 = segmented_healthy[:400]
    segmented_healthy2 = segmented_healthy[400:800]
    segmented_healthy3 = segmented_healthy[800:1200]

    return ("Segmentation Results Are:",
            segmented_unhealthy1, segmented_unhealthy2, segmented_unhealthy3,
            segmented_healthy1, segmented_healthy2, segmented_healthy3)



def hjorth_parameters(signal):
    first_derivative, second_derivative = np.diff(signal), np.diff(np.diff(signal))
    activity = np.var(signal)
    mobility = np.sqrt(np.var(first_derivative) / activity)
    complexity = np.sqrt(np.var(second_derivative) / np.var(first_derivative))
    return activity, mobility, complexity

def extract_time_features(segment):
    return np.array([
        [np.mean(ch), np.var(ch), skew(ch), kurtosis(ch), *hjorth_parameters(ch)]
        for ch in segment.T
    ])

def extract_frequency_features(segment, fs=500):
    bands = {"delta": (0.5, 4), "theta": (4, 8), "alpha": (8, 13), "beta": (13, 30), "gamma": (30, 40)}
    features = []
    for ch in segment.T:
        freqs, psd = welch(ch, fs=fs, nperseg=256)
        band_powers = [np.sum(psd[(freqs >= low) & (freqs < high)]) for low, high in bands.values()]
        features.append(band_powers)
    return np.array(features)

def compute_connectivity_matrix(segment):
    hilbert_transform = hilbert(segment, axis=0)
    phase_angles = np.angle(hilbert_transform)
    connectivity_matrix = np.abs(np.exp(1j * (phase_angles[:, None, :] - phase_angles[:, :, None])).mean(axis=0))
    np.fill_diagonal(connectivity_matrix, 1)
    return connectivity_matrix

def segmented_features(segments, label):
    node_features = []
    adjacency_matrices = []
    labels = []

    for segment in segments:
        time_feats = extract_time_features(segment)
        freq_feats = extract_frequency_features(segment)
        conn_matrix = compute_connectivity_matrix(segment)

        node_feat_matrix = np.hstack([time_feats, freq_feats])
        node_features.append(node_feat_matrix)
        adjacency_matrices.append(conn_matrix)
        labels.append(label)

    return np.array(node_features), np.array(adjacency_matrices), np.array(labels)

def get_feature_extraction_result(segments_unhealthy, segments_healthy):
    uh1, uh2, uh3 = segments_unhealthy[:400], segments_unhealthy[400:800], segments_unhealthy[800:1200]
    h1, h2, h3 = segments_healthy[:400], segments_healthy[400:800], segments_healthy[800:1200]

    nf1, adj1, lab1 = segmented_features(uh1, 0)
    nf2, adj2, lab2 = segmented_features(uh2, 0)
    nf3, adj3, lab3 = segmented_features(uh3, 0)
    nf4, adj4, lab4 = segmented_features(h1, 1)
    nf5, adj5, lab5 = segmented_features(h2, 1)
    nf6, adj6, lab6 = segmented_features(h3, 1)

    final_nf1 = np.concatenate((nf1, nf4), axis=0)
    final_nf2 = np.concatenate((nf2, nf5), axis=0)
    final_nf3 = np.concatenate((nf3, nf6), axis=0)

    final_adj1 = np.concatenate((adj1, adj4), axis=0)
    final_adj2 = np.concatenate((adj2, adj5), axis=0)
    final_adj3 = np.concatenate((adj3, adj6), axis=0)

    final_labels1 = np.concatenate((lab1, lab4), axis=0)

    return (
        "Feature_Extraction Executed Successfully",
        final_nf1, final_nf2, final_nf3,
        final_adj1, final_adj2, final_adj3, final_labels1)





