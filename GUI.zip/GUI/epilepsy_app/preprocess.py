import numpy as np
import os
import mne
from sklearn.decomposition import FastICA

# -----------------
# Data Preparation
# -----------------
root_dir = 'C:/Users/fibia/OneDrive/Documents/Final project/dataset/epilepsy/ictal'

def add_paths(dir, name):
    return os.path.join(dir, name)

patient_1 = add_paths(root_dir, 'patient1')
patient_2 = add_paths(root_dir, 'patient10')
patient_3 = add_paths(root_dir, 'patient6')

def all_files(dir):
    return sorted(os.listdir(dir))

def add_link(link, file_list):
    return [os.path.join(link, f) for f in file_list]

patient_1_records = add_link(patient_1, all_files(patient_1))
patient_2_records = add_link(patient_2, all_files(patient_2))
patient_3_records = add_link(patient_3, all_files(patient_3))

# -------------------------------
# Seizure (ictal) start-end times
# -------------------------------
patient_1_times = [[2996, 3036], [1467, 1494], [1732, 1772], [1015, 1066], [1720, 1810], [327, 420], [1862, 1963]]
patient_2_times = [[6313, 6348], [6888, 6958], [2382, 2447], [3021, 3079], [3801, 3877], [4618, 4707], [1383, 1437]]
patient_3_times = [[1724,1738],[327,347],[12500,12516],[10833,10845],[506,519],[7799,7811],[9387,9403]]

# -----------------------------
# Non-ictal (healthy) patients
# -----------------------------
healthy_files = [
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/epilepsy/non-ictal/chb01_06.edf',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/epilepsy/non-ictal/chb10_01.edf',
    'C:/Users/fibia/OneDrive/Documents/Final project/dataset/epilepsy/non-ictal/chb06_07.edf'
]

# ------------------
# Extract functions
# ------------------
def extract_seizure_segments(file_paths, seizure_times):
    data_segments = []
    for path, (start, end) in zip(file_paths, seizure_times):
        raw = mne.io.read_raw_edf(path, preload=True)
        raw.crop(tmin=start, tmax=end)
        data_segments.append(raw)
    return mne.concatenate_raws(data_segments).get_data().T

def extract_baseline(file_path, start_time=0, end_time=300):
    raw = mne.io.read_raw_edf(file_path, preload=True)
    raw.crop(tmin=start_time, tmax=end_time)
    return raw.get_data().T

# ------------------
# Load Raw Data
# ------------------
def load_data():
    unhealthy_1 = extract_seizure_segments(patient_1_records, patient_1_times)
    unhealthy_2 = extract_seizure_segments(patient_2_records, patient_2_times)
    unhealthy_3 = extract_seizure_segments(patient_3_records, patient_3_times)
    
    healthy_1 = extract_baseline(healthy_files[0])
    healthy_2 = extract_baseline(healthy_files[1])
    healthy_3 = extract_baseline(healthy_files[2])
    
    return unhealthy_1, unhealthy_2, unhealthy_3, healthy_1, healthy_2, healthy_3


# ------------------
# Get Raw Result
# ------------------
def get_raw_result():
    return load_data()  # returns all 6 files separately (3 unhealthy, 3 healthy)



# ------------------
# ICA Processing
# ------------------
def ica_process(data, n_components=23):
    ica = FastICA(n_components=n_components, random_state=42)
    return ica.fit_transform(data)

def get_ica_result():
    u1, u2, u3, h1, h2, h3 = load_data()
    
    ica_u1 = ica_process(u1)
    ica_u2 = ica_process(u2)
    ica_u3 = ica_process(u3)
    
    ica_h1 = ica_process(h1)
    ica_h2 = ica_process(h2)
    ica_h3 = ica_process(h3)
    
    result = (
        f"ICA Processed Shapes:\n"
        f"Unhealthy 1: {ica_u1.shape}, Unhealthy 2: {ica_u2.shape}, Unhealthy 3: {ica_u3.shape}\n"
        f"Healthy   1: {ica_h1.shape}, Healthy   2: {ica_h2.shape}, Healthy   3: {ica_h3.shape}"
    )
    
    return result, ica_u1, ica_u2, ica_u3, ica_h1, ica_h2, ica_h3




def segment_eeg(data, window_size=256, stride=50):
    segments = [data[i:i + window_size] for i in range(0, len(data) - window_size + 1, stride)]
    return np.array(segments)

def get_segmentation_result(ica_u1, ica_u2, ica_u3, ica_h1, ica_h2, ica_h3):
    seg_u1 = segment_eeg(ica_u1)
    seg_u2 = segment_eeg(ica_u2)
    seg_u3 = segment_eeg(ica_u3)

    seg_h1 = segment_eeg(ica_h1)
    seg_h2 = segment_eeg(ica_h2)
    seg_h3 = segment_eeg(ica_h3)

    # Safely take first 500 segments or as many as available
    seg_u1 = seg_u1[:500]
    seg_u2 = seg_u2[:500]
    seg_u3 = seg_u3[:500]

    seg_h1 = seg_h1[:500]
    seg_h2 = seg_h2[:500]
    seg_h3 = seg_h3[:500]


    return ("Segmentation Results Are:",
            seg_u1, seg_u2, seg_u3,
            seg_h1, seg_h2, seg_h3)


from scipy import signal
from scipy.stats import kurtosis
from pyentrp import entropy 
import random

# -----------------------
# Temporal Feature Block
# -----------------------
def temporal_features(datas):
    final_features = []
    for data in datas:
        channel_std = np.std(data, axis=0)
        channel_var = np.var(data, axis=0)
        channel_kurtosis = kurtosis(data, axis=0)
        channel_entropy = [
            entropy.permutation_entropy(data[:, i], normalize=True)
            for i in range(data.shape[1])
        ]
        channel_data = np.stack((channel_std, channel_var, channel_kurtosis, channel_entropy), axis=0)
        transposed = channel_data.T
        combined = transposed.flatten()
        final_features.append(combined)
    return np.array(final_features)

# -----------------------
# Spectral Feature Block
# -----------------------
def feature_extract(data, seconds=1, fs=256):
    win = seconds * fs
    myparams = dict(fs=fs, nperseg=win, window=np.ones(win), noverlap=0, scaling='spectrum', return_onesided=True)
    
    power_spectral, mean_spectral_amp, spectral_entropy1 = [], [], []
    
    for i in range(len(data)):
        a = data[i]
        b, c, d = [], [], []
        for j in range(a.shape[1]):
            freqs, psd = signal.welch(a[:, j], **myparams)
            alpha_power = np.trapz(psd, freqs)
            alpha_mean = np.mean(np.sqrt(psd))
            psd_norm = psd / np.sum(psd)
            spectral_entropy = -np.sum(psd_norm * np.log2(psd_norm)) / np.log2(len(freqs))
            if np.isnan(spectral_entropy):
                spectral_entropy = random.random()
            b.append(alpha_power)
            c.append(alpha_mean)
            d.append(spectral_entropy)
        
        power_spectral.append(np.array(b).reshape(1, -1))
        mean_spectral_amp.append(np.array(c).reshape(1, -1))
        spectral_entropy1.append(np.array(d).reshape(1, -1))

    return np.array(power_spectral), np.array(mean_spectral_amp), np.array(spectral_entropy1)

# -----------------------
# Final Feature Combiner
# -----------------------
def get_feature_extraction_result(
    seg1, seg2, seg3,
    seg_non_ictal1, seg_non_ictal2, seg_non_ictal3
):
    def combine_features(segment_data, temporal_feats):
        temporal_feats = temporal_feats.reshape(temporal_feats.shape[0], 23, 4)
        temporal_feats = np.transpose(temporal_feats, (0, 2, 1))
        spectral_feats = feature_extract(segment_data)
        spectral_combined = np.concatenate(spectral_feats, axis=1)
        return np.concatenate((temporal_feats, spectral_combined), axis=1)
    
    segment_data1 = temporal_features(seg1)
    segment_data2 = temporal_features(seg2)
    segment_data3 = temporal_features(seg3)
    
    segment_non_data1 = temporal_features(seg_non_ictal1)
    segment_non_data2 = temporal_features(seg_non_ictal2)
    segment_non_data3 = temporal_features(seg_non_ictal3)
    
    var11 = combine_features(seg1, segment_data1)
    var22 = combine_features(seg2, segment_data2)
    var33 = combine_features(seg3, segment_data3)
    
    var_non_11 = combine_features(seg_non_ictal1, segment_non_data1)
    var_non_22 = combine_features(seg_non_ictal2, segment_non_data2)
    var_non_33 = combine_features(seg_non_ictal3, segment_non_data3)

    return (
        "Feature Extraction Completed(7 features extracted)",
        var11, var22, var33,
        var_non_11, var_non_22, var_non_33
    )


from sklearn.preprocessing import StandardScaler

# -----------------------
# 3D Standard Scaling
# -----------------------
def standard_scale_3d(data):
    original_shape = data.shape  # (num_samples, num_timesteps, num_features)
    reshaped_data = data.reshape(-1, original_shape[-1])  # Flatten to 2D
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(reshaped_data)  
    return scaled_data.reshape(original_shape)  # Back to original shape

def get_scaled_feature_result(var11, var22, var33, var_non_11, var_non_22, var_non_33):
    scaled_ictal_data1 = standard_scale_3d(var11)
    scaled_ictal_data2 = standard_scale_3d(var22)
    scaled_ictal_data3 = standard_scale_3d(var33)

    scaled_non_ictal_data1 = standard_scale_3d(var_non_11)
    scaled_non_ictal_data2 = standard_scale_3d(var_non_22)
    scaled_non_ictal_data3 = standard_scale_3d(var_non_33)

    return (
        "Epilepsy Feature Scaling(7 features per sample)",
        scaled_ictal_data1, scaled_ictal_data2, scaled_ictal_data3,
        scaled_non_ictal_data1, scaled_non_ictal_data2, scaled_non_ictal_data3
    )



from scipy.signal import hilbert

# ----------------------------------------------
# Compute Adjacency Matrix (Graph Connectivity)
# ----------------------------------------------
def compute_connectivity_matrix(segment):
    hilbert_transform = hilbert(segment, axis=0)
    phase_angles = np.angle(hilbert_transform)

    connectivity_matrix = np.abs(
        np.exp(1j * (phase_angles[:, None, :] - phase_angles[:, :, None])).mean(axis=0)
    )
    np.fill_diagonal(connectivity_matrix, 1)  # Add self-loops
    return connectivity_matrix

# -----------------------------------------
# Prepare Final GCN Input for Epilepsy Data
# -----------------------------------------
def get_epilepsy_graph_data(
    scaled_ictal_data1, scaled_ictal_data2, scaled_ictal_data3,
    scaled_non_ictal_data1, scaled_non_ictal_data2, scaled_non_ictal_data3
):
    def segmented_features(seg, label):
        node_features = []
        adjacency_matrices = []
        labels = []
        
        for segment in seg:
            conn_matrix = compute_connectivity_matrix(segment)
            node_features.append(segment)  # shape: (23, features)
            adjacency_matrices.append(conn_matrix)  # shape: (23, 23)
            labels.append(label)
        
        return np.array(node_features), np.array(adjacency_matrices), np.array(labels)
    
    # Ictal = 0, Non-ictal = 1
    nf1, adj1, lab1 = segmented_features(scaled_ictal_data1, 0)
    nf2, adj2, lab2 = segmented_features(scaled_ictal_data2, 0)
    nf3, adj3, lab3 = segmented_features(scaled_ictal_data3, 0)

    nf4, adj4, lab4 = segmented_features(scaled_non_ictal_data1, 1)
    nf5, adj5, lab5 = segmented_features(scaled_non_ictal_data2, 1)
    nf6, adj6, lab6 = segmented_features(scaled_non_ictal_data3, 1)

    final_nf1 = np.concatenate((nf1, nf4), axis=0)
    final_nf2 = np.concatenate((nf2, nf5), axis=0)
    final_nf3 = np.concatenate((nf3, nf6), axis=0)

    final_nf1 = np.transpose(final_nf1, (0, 2, 1))  # (samples, features, nodes)
    final_nf2 = np.transpose(final_nf2, (0, 2, 1))
    final_nf3 = np.transpose(final_nf3, (0, 2, 1))

    final_adj1 = np.concatenate((adj1, adj4), axis=0)
    final_adj2 = np.concatenate((adj2, adj5), axis=0)
    final_adj3 = np.concatenate((adj3, adj6), axis=0)

    final_labels1 = np.concatenate((lab1, lab4), axis=0)

    return (
        "Epilepsy Graph Data Prepared Successfully",
        final_nf1, final_nf2, final_nf3,
        final_adj1, final_adj2, final_adj3,
        final_labels1
    )





















