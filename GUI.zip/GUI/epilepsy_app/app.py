from flask import Flask, render_template
from preprocess import get_raw_result, get_ica_result, get_segmentation_result, get_feature_extraction_result,get_scaled_feature_result,get_epilepsy_graph_data
from sklearn.model_selection import train_test_split
from tensorflow.keras.layers import Input, Dense
from spektral.layers import GCNConv
from sklearn.model_selection import KFold
from io import BytesIO
import numpy as np
import tensorflow as tf

# ----------------------
# Caches for each stage
# ----------------------

raw_eeg_cache = {
    "unhealthy1": None,
    "unhealthy2": None,
    "unhealthy3": None,
    "healthy1": None,
    "healthy2": None,
    "healthy3": None,
    "unhealthy": None, 
    "healthy": None  
}

ica_cache = {
    "unhealthy1": None,
    "unhealthy2": None,
    "unhealthy3": None,
    "healthy1": None,
    "healthy2": None,
    "healthy3": None,
    "unhealthy": None, 
    "healthy": None 
}

segmentation_cache = {
    "unhealthy1": None,
    "unhealthy2": None,
    "unhealthy3": None,
    "healthy1": None,
    "healthy2": None,
    "healthy3": None
}

feature_cache = {
    "unhealthy1": None,
    "unhealthy2": None,
    "unhealthy3": None,
    "healthy1": None,
    "healthy2": None,
    "healthy3": None
}


scaling_cache = {
    "ictal1": None,
    "ictal2": None,
    "ictal3": None,
    "non_ictal1": None,
    "non_ictal2": None,
    "non_ictal3": None,
}

graph_cache = {
    "nf1": None,
    "nf2": None,
    "nf3": None,
    "adj1": None,
    "adj2": None,
    "adj3": None,
    "labels1": None
}


split_cache = {
    "clients_data": None,  # Should be a list of (X_train, A_train, y_train) tuples
    "test_data": None,     # List of [X_test, A_test]
    "y_test": None         # Array of labels
}



global_model = None
local_models = []


app = Flask(__name__)

def create_gcnn_model(input_shape, adjacency_shape):
    inputs = Input(shape=input_shape)
    adj = Input(shape=adjacency_shape)
    x = GCNConv(128, activation='relu')([inputs, adj])
    x = GCNConv(64, activation='relu')([x, adj])
    x = tf.reduce_mean(x, axis=1)
    x = Dense(128, activation='relu')(x)
    x = Dense(64, activation='relu')(x)
    x = Dense(32, activation='relu')(x)
    outputs = Dense(1, activation='sigmoid')(x)
    model = tf.keras.Model(inputs=[inputs, adj], outputs=outputs)
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model


@app.route('/')
def index():
    return render_template("index.html")

@app.route("/process")
def processes():
    return render_template("process.html")


@app.route('/ica')
def ica_page():
    result, u1, u2, u3, h1, h2, h3 = get_ica_result()
    
    # Store ICA results in cache
    ica_cache["unhealthy1"] = u1
    ica_cache["unhealthy2"] = u2
    ica_cache["unhealthy3"] = u3
    ica_cache["healthy1"] = h1
    ica_cache["healthy2"] = h2
    ica_cache["healthy3"] = h3
    
    print("u1 shape:", u1.shape) 

    # Convert `uh1` (u1) and `h1` to lists and pass them to the template
    uh1_values = u1[:1].tolist()  # Convert to list to display in the template
    h1_values = h1[:1].tolist()

    return render_template("ica.html", result=result, uh1_values=uh1_values, h1_values=h1_values)



@app.route('/segmentation')
def segmentation_page():
    if ica_cache["unhealthy1"] is None:
        return "<h3>Please run ICA first.</h3><a href='/process'>Go Back</a>"

    result, u1, u2, u3, h1, h2, h3 = get_segmentation_result(
        ica_cache["unhealthy1"], ica_cache["unhealthy2"], ica_cache["unhealthy3"],
        ica_cache["healthy1"], ica_cache["healthy2"], ica_cache["healthy3"]
    )

    # Cache the segmentation results
    segmentation_cache["unhealthy1"] = u1
    segmentation_cache["unhealthy2"] = u2
    segmentation_cache["unhealthy3"] = u3
    segmentation_cache["healthy1"] = h1
    segmentation_cache["healthy2"] = h2
    segmentation_cache["healthy3"] = h3


    # Render the segmentation results along with shapes
    return render_template("segmentation.html", result=result,
                           u1_shape=str(u1.shape), u2_shape=str(u2.shape), u3_shape=str(u3.shape),
                           h1_shape=str(h1.shape), h2_shape=str(h2.shape), h3_shape=str(h3.shape))



@app.route('/features')
def feature_extraction_page():
    if segmentation_cache["unhealthy1"] is None:
        return "<h3>Please run Segmentation first.</h3><a href='/process'>Go Back</a>"

    result, u1, u2, u3, h1, h2, h3 = get_feature_extraction_result(
        segmentation_cache["unhealthy1"], segmentation_cache["unhealthy2"], segmentation_cache["unhealthy3"],
        segmentation_cache["healthy1"], segmentation_cache["healthy2"], segmentation_cache["healthy3"]
    )

    feature_cache["unhealthy1"] = u1
    feature_cache["unhealthy2"] = u2
    feature_cache["unhealthy3"] = u3
    feature_cache["healthy1"] = h1
    feature_cache["healthy2"] = h2
    feature_cache["healthy3"] = h3

    return render_template("features.html", result=result)


@app.route('/scaling')
def scaling_page():
    # Check if the feature extraction step is completed
    if feature_cache["unhealthy1"] is None or feature_cache["healthy1"] is None:
        return "<h3>Please run Feature Extraction first.</h3><a href='/process'>Go Back</a>"

    # Perform feature scaling using the extracted features
    result, scaled_ictal_data1, scaled_ictal_data2, scaled_ictal_data3, \
           scaled_non_ictal_data1, scaled_non_ictal_data2, scaled_non_ictal_data3 = get_scaled_feature_result(
               feature_cache["unhealthy1"], feature_cache["unhealthy2"], feature_cache["unhealthy3"],
               feature_cache["healthy1"], feature_cache["healthy2"], feature_cache["healthy3"]
           )

    # Save scaled data in the cache
    scaling_cache["ictal1"] = scaled_ictal_data1
    scaling_cache["ictal2"] = scaled_ictal_data2
    scaling_cache["ictal3"] = scaled_ictal_data3
    scaling_cache["non_ictal1"] = scaled_non_ictal_data1
    scaling_cache["non_ictal2"] = scaled_non_ictal_data2
    scaling_cache["non_ictal3"] = scaled_non_ictal_data3

    # Prepare data for preview
    ictal_preview = scaled_ictal_data1[:1].tolist()
    non_ictal_preview = scaled_non_ictal_data1[:1].tolist()

    return render_template("scaling.html", result=result,
                           ictal_preview=ictal_preview,
                           non_ictal_preview=non_ictal_preview)



# -------------------------
# Route for Graph Construction
# -------------------------
@app.route('/graph')
def feature_graph_page():
    # Check if the scaling step has been completed
    if scaling_cache["ictal1"] is None or scaling_cache["non_ictal1"] is None:
        return "<h3>Please run Scaling first.</h3><a href='/process'>Go Back</a>"

    # Perform graph construction
    result, nf1, nf2, nf3, adj1, adj2, adj3, labels1 = get_epilepsy_graph_data(
        scaling_cache["ictal1"], scaling_cache["ictal2"], scaling_cache["ictal3"],
        scaling_cache["non_ictal1"], scaling_cache["non_ictal2"], scaling_cache["non_ictal3"]
    )

    # Save graph data in the cache
    graph_cache["nf1"] = nf1
    graph_cache["nf2"] = nf2
    graph_cache["nf3"] = nf3
    graph_cache["adj1"] = adj1
    graph_cache["adj2"] = adj2
    graph_cache["adj3"] = adj3
    graph_cache["labels1"] = labels1

    # Return results and show data shapes
    return render_template("graph.html", result=result,
                           nf1_shape=nf1.shape, nf2_shape=nf2.shape, nf3_shape=nf3.shape,
                           adj1_shape=adj1.shape, adj2_shape=adj2.shape, adj3_shape=adj3.shape,
                           labels1_shape=labels1.shape)


@app.route('/split-data')
def splitting_page():
    # Load from cache
    X1 = graph_cache["nf1"]
    X2 = graph_cache["nf2"]
    X3 = graph_cache["nf3"]
    A1 = graph_cache["adj1"]
    A2 = graph_cache["adj2"]
    A3 = graph_cache["adj3"]
    y = graph_cache["labels1"]

    # Check if all necessary data is available
    if any(item is None for item in [X1, X2, X3, A1, A2, A3, y]):
        return "<h3>Error: Complete feature extraction and graph construction first.</h3><a href='/process'>Go Back</a>"

    # Perform train-test split
    X_train_1, X_test_1, A_train_1, A_test_1, \
    X_train_2, X_test_2, A_train_2, A_test_2, \
    X_train_3, X_test_3, A_train_3, A_test_3, \
    y_train, y_test = train_test_split(
        X1, A1, X2, A2, X3, A3, y, test_size=0.2, random_state=42
    )

    # Store split data in cache for future use
    split_cache["clients_data"] = [
        (X_train_1, A_train_1, y_train),
        (X_train_2, A_train_2, y_train),
        (X_train_3, A_train_3, y_train)
    ]
    split_cache["test_data"] = [
        [X_test_1, A_test_1],
        [X_test_2, A_test_2],
        [X_test_3, A_test_3]
    ]
    split_cache["y_test"] = y_test

    # Render the split data summary page
    return render_template('split.html',
        train_samples=len(y_train),
        test_samples=len(y_test),
        client1_train=X_train_1.shape[0],
        client2_train=X_train_2.shape[0],
        client3_train=X_train_3.shape[0],
        client1_test=X_test_1.shape[0],
        client2_test=X_test_2.shape[0],
        client3_test=X_test_3.shape[0]
    )



def federated_training():
    global global_model
    global local_models

    global_model = create_gcnn_model((23, 7), (23, 23))
    local_model1 = create_gcnn_model((23, 7), (23, 23))
    local_model2 = create_gcnn_model((23, 7), (23, 23))
    local_model3 = create_gcnn_model((23, 7), (23, 23))
    local_models = [local_model1, local_model2, local_model3]

    initial_weights = global_model.get_weights()
    clients_data = split_cache["clients_data"]
    test_data = split_cache["test_data"]
    y_test = split_cache["y_test"]

    n_rounds = 10
    k_folds = 5

    for round in range(n_rounds):
        print(f"\n========== FL Round {round + 1} ==========")
        client_weights = []

        for i, (X_train, A_train, y_train) in enumerate(clients_data):
            print(f"\nTraining on Client {i+1} with {k_folds}-Fold Cross-Validation...")
            kf = KFold(n_splits=k_folds, shuffle=True, random_state=42)
            fold_weights = []

            for fold, (train_idx, val_idx) in enumerate(kf.split(X_train)):
                print(f"  Fold {fold + 1}/{k_folds}")
                X_train_fold, A_train_fold, y_train_fold = X_train[train_idx], A_train[train_idx], y_train[train_idx]
                X_val_fold, A_val_fold, y_val_fold = X_train[val_idx], A_train[val_idx], y_train[val_idx]

                local_models[i].set_weights(global_model.get_weights())

                local_models[i].fit(
                    [X_train_fold, A_train_fold], y_train_fold,
                    epochs=5, batch_size=32,
                    validation_data=([X_val_fold, A_val_fold], y_val_fold),
                    verbose=0
                )

                fold_weights.append(local_models[i].get_weights())

            avg_weights = [np.mean([fold[i] for fold in fold_weights], axis=0) for i in range(len(fold_weights[0]))]
            client_weights.append(avg_weights)

        # Aggregate client weights
        new_weights = [np.mean([client[i] for client in client_weights], axis=0) for i in range(len(client_weights[0]))]
        global_model.set_weights(new_weights)

        weight_changes = sum(
            np.linalg.norm(global_layer - initial_layer)
            for global_layer, initial_layer in zip(global_model.get_weights(), initial_weights)
        )
        print(f"Weight Change after Round {round + 1}: {weight_changes:.4f}")

        for j in range(len(test_data)):
            loss, accuracy = global_model.evaluate(test_data[j], y_test, verbose=0)
            print(f"Global Model Accuracy after Round {round + 1} on Client {j+1}: {accuracy:.4f}")

        initial_weights = global_model.get_weights()
        for k in range(len(local_models)):
            local_models[k].set_weights(initial_weights)

    return "Model training completed successfully!"


@app.route('/train-model')
def train_model():
    if split_cache["clients_data"] is None:
        return "<h3>Error: Please split the data first!</h3><a href='/process'>Go Back</a>"
    
    message = federated_training()
    return render_template("model.html", message=message)


from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

def evaluate_model(model, test_data, y_test, model_name):
    y_pred = model.predict(test_data)
    y_pred = (y_pred > 0.5).astype(int) 

    report = classification_report(y_test, y_pred, digits=4)
    cnf_matrix = confusion_matrix(y_test, y_pred)

    TN = cnf_matrix[0][0]
    FN = cnf_matrix[1][0]
    TP = cnf_matrix[1][1]
    FP = cnf_matrix[0][1]

    FP = float(FP)
    FN = float(FN)
    TP = float(TP)
    TN = float(TN)

    specificity = TN / (TN + FP)
    sensitivity = TP / (TP + FN)
    fpr = FP / (FP + TN)
    
    print(f"\n=== {model_name} ===")
    print(f"Classification report :{report}")
    print(f"Confusion Matrix:\n{cnf_matrix}")
    print(f"Accuracy     : {accuracy_score(y_test, y_pred):.4f}")
    print(f"Precision    : {precision_score(y_test, y_pred):.4f}")
    print(f"Recall       : {recall_score(y_test, y_pred):.4f}")
    print(f"F1 Score     : {f1_score(y_test, y_pred):.4f}")
    print(f"Specificity  : {specificity:.4f}")
    print(f"Sensitivity  : {sensitivity:.4f}")
    print(f"FPR          : {fpr:.4f}")

    return {
        "model_name": model_name,
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1_score": f1_score(y_test, y_pred),
        "specificity": specificity,
        "sensitivity": sensitivity,
        "false_positive_rate": fpr,
        "confusion_matrix": cnf_matrix.tolist()
    }


@app.route('/run-metrics')
def run_metrics():
    if split_cache["test_data"] is None or global_model is None or not local_models:
        return "<h3>Please make sure training is completed.</h3><a href='/process'>Go Back</a>"

    test_data = split_cache["test_data"]
    y_test = split_cache["y_test"]

    eval_results = []

    for j, model in enumerate(local_models):
        res = evaluate_model(model, test_data[j], y_test, f"Local Model {j+1}")
        eval_results.append(res)

    for k in range(len(test_data)):
        res = evaluate_model(global_model, test_data[k], y_test, f"Global Model {k+1}")
        eval_results.append(res)

    return render_template("model_results.html", results=eval_results)



import matplotlib.pyplot as plt
import io
import base64

@app.route('/show-metrics-plot')
def show_metrics_plot():
    if split_cache["test_data"] is None or global_model is None or not local_models:
        return "<h3>Please make sure training is completed.</h3><a href='/process'>Go Back</a>"

    test_data = split_cache["test_data"]
    y_test = split_cache["y_test"]

    local_plots_base64 = []
    global_plots_base64 = []

    # Local models evaluation
    for j, model in enumerate(local_models):
        res = evaluate_model(model, test_data[j], y_test, f"Local Model {j+1}")
        image_base64 = generate_metric_plot(res)
        local_plots_base64.append(image_base64)

    # Global models evaluation
    for k in range(len(test_data)):
        res = evaluate_model(global_model, test_data[k], y_test, f"Global Model {k+1}")
        image_base64 = generate_metric_plot(res)
        global_plots_base64.append(image_base64)

    return render_template("metrics_plot.html", local_images=local_plots_base64, global_images=global_plots_base64)

def generate_metric_plot(result):
    metrics = {
        "Accuracy": result["accuracy"],
        "Precision": result["precision"],
        "Recall": result["recall"],
        "F1-Score": result["f1_score"],
        "Specificity": result["specificity"],
    }

    fig, ax = plt.subplots(figsize=(8, 5.5))

    # Different colors for each metric
    colors = ['#69b3a2', '#ff9999', '#9ecae1', '#f4b400', '#ab63fa', '#ff7f0e']
    bars = ax.bar(metrics.keys(), metrics.values(), color=colors[:len(metrics)])

    # Annotate values inside bars
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f"{height:.4f}",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 5),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=11, color='black', fontweight='bold')

    ax.set_title(result["model_name"], fontsize=15, fontweight='bold', pad=15)
    ax.set_ylim(0, 1.10)

    ax.tick_params(axis='x', labelsize=12)
    ax.tick_params(axis='y', labelsize=11)

    for spine in ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1.4)

    fig.tight_layout(pad=2.5)

    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    plt.close(fig)

    return image_base64




# Function to generate EEG plot (based on your raw data format)
def generate_eeg_plot(data, title):
    plt.figure(figsize=(12, 6))  # Increase size for better visualization
    plt.plot(data, color='b')  # Plot using matplotlib (raw data directly)
    plt.title(title)
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    
    # Save the plot as a base64 encoded string to display in the browser
    img = BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')  # bbox_inches='tight' to avoid clipping
    img.seek(0)
    img_base64 = base64.b64encode(img.getvalue()).decode('utf8')
    plt.close()
    return img_base64



@app.route('/show-unhealthy-eeg')
def show_unhealthy_eeg():
    # Retrieve raw EEG data
    unhealthy1, unhealthy2, unhealthy3, _, _, _ = get_raw_result()
    raw_eeg_cache["unhealthy"] = [unhealthy1, unhealthy2, unhealthy3]

    if raw_eeg_cache["unhealthy"] is None:
        return "<h3>Unhealthy EEG data not available. Run processing first.</h3><a href='/process'>Go Back</a>"

    eeg_data = raw_eeg_cache["unhealthy"][2]  # Use the first sample
    eeg_plot = generate_eeg_plot(eeg_data, title="Unhealthy EEG Signal")

    return render_template('plot.html', plot=eeg_plot, plot_title="Unhealthy EEG Plot")

@app.route('/show-healthy-eeg')
def show_healthy_eeg():
    # Retrieve raw EEG data
    _, _, _, healthy1, healthy2, healthy3 = get_raw_result()
    raw_eeg_cache["healthy"] = [healthy1, healthy2, healthy3]

    if raw_eeg_cache["healthy"] is None:
        return "<h3>Healthy EEG data not available. Run processing first.</h3><a href='/process'>Go Back</a>"

    eeg_data = raw_eeg_cache["healthy"][2]  # Use the first sample
    eeg_plot = generate_eeg_plot(eeg_data, title="Healthy EEG Signal")

    return render_template('plot.html', plot=eeg_plot, plot_title="Healthy EEG Plot")

if __name__ == '__main__':
    app.run(debug=True,use_reloader=False)
